import React from "react";

function First(){
    return(
        <div>
            <h1>FIRST PAGE</h1>
            
        </div>
    )
}

export default First;